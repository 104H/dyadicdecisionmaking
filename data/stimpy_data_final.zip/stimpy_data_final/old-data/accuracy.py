import pandas as pd
import numpy as np

df = pd.read_csv('DDM_pair2_2021_Sep_22_0931.csv')
df = df[['condition','response']]

conditions = [
    (df['condition'] == 'signal') & (df['response'] == 2),
    (df['condition'] == 'signal') & (df['response'] == 1),
    (df['condition'] == 'noise')  & (df['response'] == 2),
    (df['condition'] == 'noise')  & (df['response'] == 1),
    (df['response'] == 'noresponse')
]
values = ['hit', 'miss', 'false-alarm', 'correct-reject', 'no-response']


df['outcome'] = np.select(conditions, values)

accuracy = df[df['outcome'].isin(['hit','correct-reject'])].shape[0]/df.shape[0]
print("     Overall Accuracy %.2f\n" % (accuracy*100))
print(df.groupby(['condition'])['outcome'].value_counts(normalize=True,sort=False)*100)
